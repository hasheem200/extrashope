// HStore - Main JavaScript

// ==================== DATA STORE ====================
// Fresh store with first user, first product, first sale
// Initialize fresh - clear old data
initFreshStore();

const store = {
    // First product - starts from here when user adds
    products: [
        { id: 1, name: 'Sample Product', category: 'electronics', price: 99, seller: 'SampleStore', sellerId: 1, image: '📦', rating: 5.0, sales: 0, description: 'Your first product will appear here.' }
    ],
    
    // First seller
    sellers: [
        { id: 1, name: 'SampleStore', avatar: 'S', rating: 5.0, sales: 0, products: 1, verified: true }
    ],
    
    // First user
    users: [
        { id: 1, name: 'First User', email: 'user@hstore.site', phone: '', address: '', joined: new Date().toISOString() }
    ],
    
    wallet: {
        balances: {
            USD: 0,
            USDT: 0
        },
        // Deposit history
        deposits: [],
        // Withdraw history
        withdrawals: [],
        // P2P transaction history
        p2pTransactions: []
    },
    
    p2pOrders: {
        buy: [],
        sell: []
    },
    
    cart: [],
    
    // First order - starts from here
    orders: []
};

// ==================== UTILITY FUNCTIONS ====================
// Auto-reset store data on page load - fresh start every time
(function() {
    // Clear all store data on every page load for fresh start
    localStorage.removeItem('hstore_data');
    localStorage.removeItem('hstore_fresh');
    localStorage.removeItem('hstore_adminUsers');
    localStorage.removeItem('hstore_adminSellers');
    localStorage.removeItem('hstore_adminProfile');
    // Keep user sessions
    const currentUser = localStorage.getItem('hstore_currentUser');
    const adminUser = localStorage.getItem('adminUser');
})();

// Reset all store data - clear everything and start fresh
function resetAllStoreData() {
    if (confirm('Are you sure you want to reset ALL store data? This will clear all users, products, orders, and transactions. This action cannot be undone.')) {
        localStorage.removeItem('hstore_data');
        localStorage.removeItem('hstore_currentUser');
        localStorage.removeItem('hstore_messages');
        localStorage.removeItem('adminUser');
        localStorage.removeItem('hstore_fresh');
        localStorage.removeItem('hstore_adminUsers');
        localStorage.removeItem('hstore_adminSellers');
        
        alert('All store data has been reset!');
        window.location.href = 'index.html';
    }
}

// Initialize store - keep user and admin logged in, only clear store data on first load
function initFreshStore() {
    // Only clear data if not already initialized this session
    if (!localStorage.getItem('hstore_fresh')) {
        const currentUser = localStorage.getItem('hstore_currentUser');
        const adminUser = localStorage.getItem('adminUser');
        
        localStorage.removeItem('hstore_data');
        localStorage.removeItem('hstore_messages');
        
        // Restore user session
        if (currentUser) {
            localStorage.setItem('hstore_currentUser', currentUser);
        }
        if (adminUser) {
            localStorage.setItem('adminUser', adminUser);
        }
        
        localStorage.setItem('hstore_fresh', 'true');
    }
    
    // Initialize sample data if store is empty
    const store = getStoreData();
    if (store.products.length === 0) {
        initializeSampleData();
    }
}

// Initialize sample data for demo
function initializeSampleData() {
    const sampleProducts = [
        { id: 1, name: 'iPhone 15 Pro', category: 'electronics', price: 999, image: '📱', description: 'Latest iPhone with A17 chip', seller: 'TechStore', sellerEmail: 'tech@store.com', rating: 4.8, sales: 45 },
        { id: 2, name: 'MacBook Pro M3', category: 'electronics', price: 1999, image: '💻', description: 'Powerful laptop for professionals', seller: 'TechStore', sellerEmail: 'tech@store.com', rating: 4.9, sales: 23 },
        { id: 3, name: 'Nike Air Max', category: 'fashion', price: 150, image: '👟', description: 'Comfortable running shoes', seller: 'FashionHub', sellerEmail: 'fashion@hub.com', rating: 4.5, sales: 89 },
        { id: 4, name: 'Sony WH-1000XM5', category: 'electronics', price: 349, image: '🎧', description: 'Premium noise cancelling headphones', seller: 'TechStore', sellerEmail: 'tech@store.com', rating: 4.7, sales: 67 },
        { id: 5, name: 'Gaming Chair', category: 'home', price: 299, image: '🪑', description: 'Ergonomic gaming chair', seller: 'HomeDecor', sellerEmail: 'home@decor.com', rating: 4.4, sales: 34 },
        { id: 6, name: 'Smart Watch', category: 'electronics', price: 299, image: '⌚', description: 'Fitness tracking smartwatch', seller: 'TechStore', sellerEmail: 'tech@store.com', rating: 4.6, sales: 78 }
    ];
    
    const sampleOrders = [
        { id: 'ORD-001', buyerEmail: 'john@example.com', items: [{ product: sampleProducts[0], quantity: 1 }], subtotal: 999, tax: 99.9, total: 1098.9, sellerEarnings: 899.1, status: 'delivered', date: new Date().toISOString() },
        { id: 'ORD-002', buyerEmail: 'jane@example.com', items: [{ product: sampleProducts[2], quantity: 2 }], subtotal: 300, tax: 30, total: 330, sellerEarnings: 270, status: 'shipped', date: new Date().toISOString() },
        { id: 'ORD-003', buyerEmail: 'mike@example.com', items: [{ product: sampleProducts[3], quantity: 1 }], subtotal: 349, tax: 34.9, total: 383.9, sellerEarnings: 314.1, status: 'processing', date: new Date().toISOString() }
    ];
    
    const store = getStoreData();
    store.products = sampleProducts;
    store.orders = sampleOrders;
    saveStoreData(store);
}

// Reset store to fresh start - call this to clear all data
function resetStoreToFresh() {
    localStorage.removeItem('hstore_data');
    localStorage.removeItem('hstore_currentUser');
    localStorage.removeItem('hstore_messages');
    localStorage.removeItem('adminUser');
    localStorage.removeItem('hstore_fresh');
    location.reload();
}

function saveData() {
    localStorage.setItem('hstore_data', JSON.stringify(store));
}

function getStoreData() {
    return JSON.parse(localStorage.getItem('hstore_data') || '{"products":[],"orders":[],"cart":[],"wallet":{"USDT":0,"BTC":0,"ETH":0},"p2pOrders":[],"adminRevenue":0}');
}

function saveStoreData(storeData) {
    localStorage.setItem('hstore_data', JSON.stringify(storeData));
}

function loadData() {
    const data = localStorage.getItem('hstore_data');
    if (data) {
        const parsed = JSON.parse(data);
        Object.assign(store, parsed);
    }
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function formatCurrency(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

// ==================== PRODUCT FUNCTIONS ====================
function loadFeaturedProducts() {
    const container = document.getElementById('featuredProducts');
    if (!container) return;
    
    const products = store.products.slice(0, 8);
    container.innerHTML = products.map(product => `
        <div class="product-card" onclick="viewProduct(${product.id})">
            <div class="product-image">${product.image}</div>
            <div class="product-info">
                <h3>${product.name}</h3>
                <p class="product-seller">by ${product.seller}</p>
                <div class="product-price">${formatCurrency(product.price)}</div>
                <div class="product-actions">
                    <button class="btn btn-primary" onclick="event.stopPropagation(); addToCart(${product.id})">Add to Cart</button>
                    <button class="btn btn-outline" onclick="event.stopPropagation(); buyNow(${product.id})">Buy Now</button>
                </div>
            </div>
        </div>
    `).join('');
}

function loadTopSellers() {
    const container = document.getElementById('topSellers');
    if (!container) return;
    
    const sellers = store.sellers.slice(0, 4);
    container.innerHTML = sellers.map(seller => `
        <div class="seller-card">
            <div class="seller-avatar">${seller.avatar}</div>
            <div class="seller-details">
                <h3>${seller.name} ${seller.verified ? '✅' : ''}</h3>
                <p>${seller.products} products</p>
                <div class="seller-rating">${'⭐'.repeat(Math.floor(seller.rating))} ${seller.rating}</div>
            </div>
        </div>
    `).join('');
}

function viewProduct(id) {
    const product = store.products.find(p => p.id === id);
    if (!product) return;
    
    window.location.href = `product.html?id=${id}`;
}

function filterCategory(category) {
    window.location.href = `discover.html?category=${category}`;
}

function searchProducts() {
    const query = document.getElementById('searchInput').value;
    if (query) {
        window.location.href = `discover.html?search=${encodeURIComponent(query)}`;
    }
}

// ==================== CART FUNCTIONS ====================
function addToCart(productId) {
    const product = store.products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = store.cart.find(item => item.productId === productId);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        store.cart.push({
            productId: productId,
            quantity: 1
        });
    }
    
    saveData();
    updateCartCount();
    showNotification(`${product.name} added to cart!`);
}

function removeFromCart(productId) {
    store.cart = store.cart.filter(item => item.productId !== productId);
    saveData();
    loadCart();
    updateCartCount();
}

function updateCartQuantity(productId, change) {
    const item = store.cart.find(item => item.productId === productId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(productId);
        } else {
            saveData();
            loadCart();
        }
    }
}

function updateCartCount() {
    const count = store.cart.reduce((sum, item) => sum + item.quantity, 0);
    const countElements = document.querySelectorAll('#cartCount');
    countElements.forEach(el => el.textContent = count);
}

function getCartTotal() {
    return store.cart.reduce((total, item) => {
        const product = store.products.find(p => p.id === item.productId);
        return total + (product ? product.price * item.quantity : 0);
    }, 0);
}

function getCartItems() {
    return store.cart.map(item => {
        const product = store.products.find(p => p.id === item.productId);
        return {
            ...item,
            product: product
        };
    }).filter(item => item.product);
}

function loadCart() {
    const container = document.getElementById('cartItems');
    if (!container) return;
    
    const items = getCartItems();
    
    if (items.length === 0) {
        container.innerHTML = `
            <tr>
                <td colspan="6">
                    <div class="empty-state">
                        <div class="icon">🛒</div>
                        <h3>Your cart is empty</h3>
                        <p>Start shopping to add items to your cart</p>
                        <a href="discover.html" class="btn btn-primary">Browse Products</a>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    container.innerHTML = items.map(item => `
        <tr>
            <td>
                <div class="cart-item-image">${item.product.image}</div>
            </td>
            <td>
                <h4>${item.product.name}</h4>
                <p class="product-seller">by ${item.product.seller}</p>
            </td>
            <td>${formatCurrency(item.product.price)}</td>
            <td>
                <div class="quantity-selector">
                    <button class="quantity-btn" onclick="updateCartQuantity(${item.productId}, -1)">-</button>
                    <span class="quantity-value">${item.quantity}</span>
                    <button class="quantity-btn" onclick="updateCartQuantity(${item.productId}, 1)">+</button>
                </div>
            </td>
            <td>${formatCurrency(item.product.price * item.quantity)}</td>
            <td>
                <button class="btn btn-danger" onclick="removeFromCart(${item.productId})">Remove</button>
            </td>
        </tr>
    `).join('');
    
    const subtotal = getCartTotal();
    document.getElementById('cartSubtotal').textContent = formatCurrency(subtotal);
    document.getElementById('cartTotal').textContent = formatCurrency(subtotal);
}

function buyNow(productId) {
    addToCart(productId);
    window.location.href = 'checkout.html';
}

function clearCart() {
    store.cart = [];
    saveData();
    updateCartCount();
    loadCart();
}

// ==================== P2P EXCHANGE FUNCTIONS ====================
function loadP2POrders(type = 'buy') {
    const container = document.getElementById('p2pOrderList');
    if (!container) return;
    
    const orders = store.p2pOrders[type];
    container.innerHTML = orders.map(order => `
        <div class="p2p-order-card">
            <div class="header">
                <span class="user">${order.user}</span>
                <span class="price">${formatCurrency(order.price)} ${order.currency.split('/')[1]}</span>
            </div>
            <div class="limits">Limit: ${formatCurrency(order.minLimit)} - ${formatCurrency(order.maxLimit)}</div>
            <div class="payment-methods">
                ${order.paymentMethods.map(method => `<span class="payment-badge">${method}</span>`).join('')}
            </div>
            <button class="btn btn-primary" onclick="openP2PTradeModal(${order.id}, '${type}')">Trade</button>
        </div>
    `).join('');
}

function openP2PTradeModal(orderId, type) {
    const order = (store.p2pOrders[type] || []).find(o => o.id === orderId);
    if (!order) return;
    
    document.getElementById('p2pOrderId').value = orderId;
    document.getElementById('p2pOrderType').value = type;
    document.getElementById('p2pTradeUser').textContent = order.user;
    document.getElementById('p2pTradePrice').textContent = `${formatCurrency(order.price)} ${order.currency.split('/')[1]}`;
    document.getElementById('p2pTradeAmount').value = '';
    document.getElementById('p2pTradeAmount').max = order.amount;
    
    document.getElementById('tradeModal').classList.add('active');
}

function closeTradeModal() {
    document.getElementById('tradeModal').classList.remove('active');
}

function executeP2PTrade() {
    const orderId = parseInt(document.getElementById('p2pOrderId').value);
    const type = document.getElementById('p2pOrderType').value;
    const amount = parseFloat(document.getElementById('p2pTradeAmount').value);
    
    if (!amount || amount <= 0) {
        showNotification('Please enter a valid amount', 'error');
        return;
    }
    
    const order = (store.p2pOrders[type] || []).find(o => o.id === orderId);
    if (!order) return;
    
    if (amount < order.minLimit || amount > order.maxLimit) {
        showNotification(`Amount must be between ${formatCurrency(order.minLimit)} and ${formatCurrency(order.maxLimit)}`, 'error');
        return;
    }
    
    const total = amount * order.price;
    
    if (type === 'buy') {
        store.wallet.balances.USDT -= total;
    } else {
        store.wallet.balances.USDT += total;
    }
    
    // Add to P2P transaction history
    if (!store.wallet.p2pTransactions) store.wallet.p2pTransactions = [];
    store.wallet.p2pTransactions.unshift({
        date: new Date().toISOString(),
        type: type,
        counterparty: order.user,
        amount: amount,
        price: order.price,
        total: total,
        status: 'completed'
    });
    
    store.wallet.transactions.unshift({
        id: Date.now(),
        type: type === 'buy' ? 'buy' : 'sell',
        amount: amount,
        price: order.price,
        total: total,
        currency: order.currency,
        user: order.user,
        date: new Date().toISOString()
    });
    
    saveData();
    closeTradeModal();
    showNotification(`Trade executed! ${type === 'buy' ? 'Bought' : 'Sold'} ${amount} USDT`);
    loadWalletTransactions();
}

function createP2POrder() {
    const type = document.getElementById('createOrderType').value;
    const price = parseFloat(document.getElementById('createOrderPrice').value);
    const amount = parseFloat(document.getElementById('createOrderAmount').value);
    const minLimit = parseFloat(document.getElementById('createOrderMin').value);
    const maxLimit = parseFloat(document.getElementById('createOrderMax').value);
    const paymentMethods = Array.from(document.querySelectorAll('#createOrderMethods input:checked')).map(cb => cb.value);
    
    if (!price || !amount || !minLimit || !maxLimit || paymentMethods.length === 0) {
        showNotification('Please fill all fields', 'error');
        return;
    }
    
    const newOrder = {
        id: Date.now(),
        user: 'You',
        price: price,
        amount: amount,
        minLimit: minLimit,
        maxLimit: maxLimit,
        paymentMethods: paymentMethods,
        currency: 'USD/USDT'
    };
    
    store.p2pOrders[type].push(newOrder);
    saveData();
    loadP2POrders(type);
    showNotification('Order created successfully!');
}

// ==================== WALLET FUNCTIONS ====================
function loadWalletBalance() {
    const balances = store.wallet.balances;
    document.getElementById('usdBalance').textContent = formatCurrency(balances.USD);
    document.getElementById('eurBalance').textContent = formatCurrency(balances.EUR);
    document.getElementById('gbpBalance').textContent = formatCurrency(balances.GBP);
    document.getElementById('pkrBalance').textContent = formatCurrency(balances.PKR);
    document.getElementById('usdtBalance').textContent = formatCurrency(balances.USDT);
    
    const totalUSD = balances.USD + (balances.USDT * 1);
    document.getElementById('totalBalance').textContent = formatCurrency(totalUSD);
}

function loadWalletTransactions() {
    const container = document.getElementById('walletTransactions');
    if (!container) return;
    
    const transactions = store.wallet.transactions;
    
    if (transactions.length === 0) {
        container.innerHTML = `
            <tr>
                <td colspan="6">
                    <div class="empty-state">
                        <div class="icon">💰</div>
                        <h3>No transactions yet</h3>
                        <p>Your transaction history will appear here</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    container.innerHTML = transactions.map(tx => `
        <tr>
            <td>${new Date(tx.date).toLocaleDateString()}</td>
            <td><span class="transaction-type ${tx.type}">${tx.type.toUpperCase()}</span></td>
            <td>${tx.currency}</td>
            <td>${tx.amount}</td>
            <td>${formatCurrency(tx.price)}</td>
            <td>${formatCurrency(tx.total)}</td>
        </tr>
    `).join('');
}

function depositToWallet() {
    const amount = parseFloat(document.getElementById('depositAmount').value);
    const currency = document.getElementById('depositCurrency').value;
    
    if (!amount || amount <= 0) {
        showNotification('Please enter a valid amount', 'error');
        return;
    }
    
    store.wallet.balances[currency] += amount;
    
    // Add to deposit history
    if (!store.wallet.deposits) store.wallet.deposits = [];
    store.wallet.deposits.unshift({
        date: new Date().toISOString(),
        method: 'Bank Transfer',
        amount: amount,
        status: 'completed',
        reference: 'DEP-' + Date.now()
    });
    
    store.wallet.transactions.unshift({
        id: Date.now(),
        type: 'deposit',
        amount: amount,
        currency: currency,
        date: new Date().toISOString()
    });
    
    saveData();
    loadWalletBalance();
    loadWalletTransactions();
    closeDepositModal();
    showNotification(`Deposited ${formatCurrency(amount)} ${currency} to wallet`);
}

function openWithdrawModal() {
    document.getElementById('withdrawModal').classList.add('active');
}

function closeWithdrawModal() {
    document.getElementById('withdrawModal').classList.remove('active');
}

function withdrawFromWallet() {
    const amount = parseFloat(document.getElementById('withdrawAmount').value);
    const currency = document.getElementById('withdrawCurrency').value;
    
    if (!amount || amount <= 0) {
        showNotification('Please enter a valid amount', 'error');
        return;
    }
    
    if (amount > store.wallet.balances[currency]) {
        showNotification('Insufficient balance', 'error');
        return;
    }
    
    store.wallet.balances[currency] -= amount;
    
    // Add to withdrawal history
    if (!store.wallet.withdrawals) store.wallet.withdrawals = [];
    store.wallet.withdrawals.unshift({
        date: new Date().toISOString(),
        method: 'Bank Transfer',
        amount: amount,
        status: 'pending',
        reference: 'WTH-' + Date.now()
    });
    
    store.wallet.transactions.unshift({
        id: Date.now(),
        type: 'withdraw',
        amount: amount,
        currency: currency,
        date: new Date().toISOString()
    });
    
    saveData();
    loadWalletBalance();
    loadWalletTransactions();
    closeWithdrawModal();
    showNotification(`Withdrawn ${formatCurrency(amount)} ${currency}`);
}

// ==================== ORDER FUNCTIONS ====================
function createOrder() {
    const items = getCartItems();
    if (items.length === 0) {
        showNotification('Cart is empty', 'error');
        return;
    }
    
    const currentUser = JSON.parse(localStorage.getItem('hstore_currentUser') || 'null');
    const buyerEmail = currentUser ? currentUser.email : 'guest@example.com';
    
    const order = {
        id: 'ORD-' + Date.now(),
        items: items.map(item => ({
            ...item,
            product: {
                ...item.product,
                sellerEmail: item.product.sellerEmail || 'unknown@seller.com'
            }
        })),
        buyerEmail: buyerEmail,
        subtotal: getCartTotal(),
        tax: getCartTotal() * 0.10, // 10% platform tax
        total: getCartTotal() + (getCartTotal() * 0.10),
        sellerEarnings: getCartTotal() * 0.90, // 90% to seller
        status: 'pending',
        date: new Date().toISOString()
    };
    
    store.orders.unshift(order);
    store.adminRevenue = (store.adminRevenue || 0) + (getCartTotal() * 0.10);
    saveData();
    clearCart();
    
    showNotification('Order placed successfully! 10% tax collected for platform.');
    window.location.href = 'orders.html';
}

function loadOrders() {
    const container = document.getElementById('orderList');
    if (!container) return;
    
    if (store.orders.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div class="icon">📦</div>
                <h3>No orders yet</h3>
                <p>Your order history will appear here</p>
                <a href="discover.html" class="btn btn-primary">Start Shopping</a>
            </div>
        `;
        return;
    }
    
    container.innerHTML = store.orders.map(order => `
        <div class="order-card">
            <div class="order-header">
                <span class="order-id">${order.id}</span>
                <span class="order-date">${new Date(order.date).toLocaleDateString()}</span>
            </div>
            <div class="order-items">
                ${order.items.map(item => `
                    <div class="order-item">
                        <div class="order-item-image">${item.product.image}</div>
                        <div class="order-item-details">
                            <h4>${item.product.name}</h4>
                            <p>Qty: ${item.quantity} × ${formatCurrency(item.product.price)}</p>
                        </div>
                    </div>
                `).join('')}
            </div>
            <div class="order-footer">
                <span class="status-badge ${order.status}">${order.status}</span>
                <span class="order-total">Total: ${formatCurrency(order.total)}</span>
            </div>
        </div>
    `).join('');
}

// ==================== AUTH FUNCTIONS ====================
function login(email, password) {
    const user = store.users.find(u => u.email === email && u.password === password);
    if (user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        showNotification('Login successful!');
        window.location.href = 'index.html';
    } else {
        showNotification('Invalid email or password', 'error');
    }
}

function register(name, email, password) {
    if (store.users.find(u => u.email === email)) {
        showNotification('Email already registered', 'error');
        return;
    }
    
    const newUser = {
        id: Date.now(),
        name: name,
        email: email,
        password: password,
        createdAt: new Date().toISOString()
    };
    
    store.users.push(newUser);
    saveData();
    
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    showNotification('Registration successful!');
    window.location.href = 'index.html';
}

function logout() {
    localStorage.removeItem('currentUser');
    showNotification('Logged out successfully');
    window.location.href = 'index.html';
}

function getCurrentUser() {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
}

// ==================== SELLER FUNCTIONS ====================
function loadSellerProducts() {
    const container = document.getElementById('sellerProductList');
    if (!container) return;
    
    const products = store.products;
    
    container.innerHTML = products.map(product => `
        <tr>
            <td>${product.image}</td>
            <td>${product.name}</td>
            <td>${product.category}</td>
            <td>${formatCurrency(product.price)}</td>
            <td>${product.sales}</td>
            <td><span class="status-badge active">Active</span></td>
            <td>
                <button class="btn btn-outline" onclick="editProduct(${product.id})">Edit</button>
                <button class="btn btn-danger" onclick="deleteProduct(${product.id})">Delete</button>
            </td>
        </tr>
    `).join('');
}

function addNewProduct() {
    const name = document.getElementById('productName').value;
    const price = parseFloat(document.getElementById('productPrice').value);
    const category = document.getElementById('productCategory').value;
    const description = document.getElementById('productDescription').value;
    const image = document.getElementById('productImage').value || '📦';
    
    if (!name || !price || !category) {
        showNotification('Please fill all required fields', 'error');
        return;
    }
    
    const newProduct = {
        id: Date.now(),
        name: name,
        price: price,
        category: category,
        description: description,
        image: image,
        seller: getCurrentUser() ? getCurrentUser().name : 'You',
        sellerId: getCurrentUser() ? getCurrentUser().id : 1,
        rating: 0,
        sales: 0
    };
    
    store.products.push(newProduct);
    saveData();
    closeProductModal();
    loadSellerProducts();
    showNotification('Product added successfully!');
}

function editProduct(id) {
    const product = store.products.find(p => p.id === id);
    if (!product) return;
    
    document.getElementById('productName').value = product.name;
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productCategory').value = product.category;
    document.getElementById('productDescription').value = product.description;
    document.getElementById('productId').value = product.id;
    
    document.getElementById('productModalTitle').textContent = 'Edit Product';
    document.getElementById('productModal').classList.add('active');
}

function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product?')) {
        store.products = store.products.filter(p => p.id !== id);
        saveData();
        loadSellerProducts();
        showNotification('Product deleted');
    }
}

function openProductModal() {
    document.getElementById('productId').value = '';
    document.getElementById('productName').value = '';
    document.getElementById('productPrice').value = '';
    document.getElementById('productCategory').value = '';
    document.getElementById('productDescription').value = '';
    document.getElementById('productModalTitle').textContent = 'Add New Product';
    document.getElementById('productModal').classList.add('active');
}

function closeProductModal() {
    document.getElementById('productModal').classList.remove('active');
}

// ==================== DISCOVER PAGE ====================
function loadDiscoverProducts() {
    const container = document.getElementById('discoverProductGrid');
    if (!container) return;
    
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category');
    const search = urlParams.get('search');
    
    let products = store.products;
    
    if (category) {
        products = products.filter(p => p.category === category);
    }
    
    if (search) {
        const query = search.toLowerCase();
        products = products.filter(p => 
            p.name.toLowerCase().includes(query) || 
            p.description.toLowerCase().includes(query)
        );
    }
    
    container.innerHTML = products.map(product => `
        <div class="product-card" onclick="viewProduct(${product.id})">
            <div class="product-image">${product.image}</div>
            <div class="product-info">
                <h3>${product.name}</h3>
                <p class="product-seller">by ${product.seller}</p>
                <div class="product-price">${formatCurrency(product.price)}</div>
                <div class="product-actions">
                    <button class="btn btn-primary" onclick="event.stopPropagation(); addToCart(${product.id})">Add to Cart</button>
                </div>
            </div>
        </div>
    `).join('');
}

// ==================== PRODUCT DETAIL PAGE ====================
function loadProductDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = parseInt(urlParams.get('id'));
    
    const product = store.products.find(p => p.id === productId);
    if (!product) {
        window.location.href = 'discover.html';
        return;
    }
    
    document.getElementById('productName').textContent = product.name;
    document.getElementById('productImage').textContent = product.image;
    document.getElementById('productPrice').textContent = formatCurrency(product.price);
    document.getElementById('productDescription').textContent = product.description;
    document.getElementById('productSeller').textContent = product.seller;
    document.getElementById('productCategory').textContent = product.category;
    document.getElementById('productRating').textContent = '⭐'.repeat(Math.floor(product.rating)) + ` (${product.rating})`;
    document.getElementById('productSales').textContent = `${product.sales} sales`;
    
    window.productData = product;
}

let quantity = 1;

function increaseQuantity() {
    quantity++;
    document.getElementById('quantityValue').textContent = quantity;
}

function decreaseQuantity() {
    if (quantity > 1) {
        quantity--;
        document.getElementById('quantityValue').textContent = quantity;
    }
}

function addToCartFromDetail() {
    addToCart(window.productData.id);
}

// ==================== SELLERS PAGE ====================
function loadSellersList() {
    const container = document.getElementById('sellersList');
    if (!container) return;
    
    container.innerHTML = store.sellers.map(seller => `
        <div class="seller-card">
            <div class="seller-avatar">${seller.avatar}</div>
            <div class="seller-details">
                <h3>${seller.name} ${seller.verified ? '✅' : ''}</h3>
                <p>${seller.products} products • ${seller.sales} sales</p>
                <div class="seller-rating">${'⭐'.repeat(Math.floor(seller.rating))} ${seller.rating}</div>
            </div>
            <a href="store.html?seller=${seller.id}" class="btn btn-primary">View Store</a>
        </div>
    `).join('');
}

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    loadData();
    
    updateCartCount();
    checkUserLogin();
    
    const path = window.location.pathname;
    
    if (path.includes('cart.html')) {
        loadCart();
    } else if (path.includes('orders.html')) {
        loadOrders();
    } else if (path.includes('discover.html')) {
        loadDiscoverProducts();
    } else if (path.includes('product.html')) {
        loadProductDetail();
    } else if (path.includes('sellers.html')) {
        loadSellersList();
    } else if (path.includes('seller-products.html')) {
        loadSellerProducts();
    } else if (path.includes('wallet.html')) {
        loadWalletBalance();
        loadWalletTransactions();
    } else if (path.includes('p2p-exchange.html')) {
        loadP2POrders('buy');
    }
});

// Check user login and update header
function checkUserLogin() {
    const currentUser = JSON.parse(localStorage.getItem('hstore_currentUser') || 'null');
    const adminUser = localStorage.getItem('adminUser');
    const userMenuBtn = document.getElementById('userMenuBtn');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const adminBtn = document.getElementById('adminBtn');
    
    if (adminUser) {
        // Admin is logged in - show admin button, hide user menu
        if (userMenuBtn) {
            userMenuBtn.style.display = 'none';
        }
        if (loginBtn) {
            loginBtn.style.display = 'none';
        }
        if (logoutBtn) {
            logoutBtn.style.display = 'inline-flex';
        }
        if (adminBtn) {
            adminBtn.style.display = 'inline-flex';
        }
    } else if (currentUser) {
        // Regular user is logged in - hide admin button
        if (userMenuBtn) {
            userMenuBtn.style.display = 'inline-flex';
            userMenuBtn.textContent = '👤 ' + (currentUser.name || 'User');
        }
        if (loginBtn) {
            loginBtn.style.display = 'none';
        }
        if (logoutBtn) {
            logoutBtn.style.display = 'inline-flex';
        }
        if (adminBtn) {
            adminBtn.style.display = 'none';
        }
    } else {
        // No one is logged in
        if (userMenuBtn) {
            userMenuBtn.style.display = 'none';
        }
        if (loginBtn) {
            loginBtn.style.display = 'inline-flex';
        }
        if (logoutBtn) {
            logoutBtn.style.display = 'none';
        }
        if (adminBtn) {
            adminBtn.style.display = 'none';
        }
    }
}

// Logout user
function userLogout() {
    localStorage.removeItem('hstore_currentUser');
    window.location.href = 'index.html';
}

// Export for use in other files
window.store = store;
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateCartQuantity = updateCartQuantity;
window.viewProduct = viewProduct;
window.filterCategory = filterCategory;
window.searchProducts = searchProducts;
window.buyNow = buyNow;
window.clearCart = clearCart;
window.createOrder = createOrder;
window.loadP2POrders = loadP2POrders;
window.openP2PTradeModal = openP2PTradeModal;
window.closeTradeModal = closeTradeModal;
window.executeP2PTrade = executeP2PTrade;
window.createP2POrder = createP2POrder;
window.depositToWallet = depositToWallet;
window.withdrawFromWallet = withdrawFromWallet;
window.openWithdrawModal = openWithdrawModal;
window.closeWithdrawModal = closeWithdrawModal;
window.openProductModal = openProductModal;
window.closeProductModal = closeProductModal;
window.addNewProduct = addNewProduct;
window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
window.increaseQuantity = increaseQuantity;
window.decreaseQuantity = decreaseQuantity;
window.addToCartFromDetail = addToCartFromDetail;
window.formatCurrency = formatCurrency;
window.showNotification = showNotification;
window.getCurrentUser = getCurrentUser;
window.logout = logout;
window.checkUserLogin = checkUserLogin;
window.getStoreData = getStoreData;
window.saveStoreData = saveStoreData;
window.userLogout = userLogout;